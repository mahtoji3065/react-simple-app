import React, { Component } from 'react';

export default class Login extends Component {

  constructor(props) {
    super(props)
    this.state = {
      validUserName: 'govinda',
      validPassword: 'mahto',
      fields: {
        username: '',
        password: ''
      },
      formFieldError: {
        username: '',
        password: ''
      },
    }
  }

  accessLogin() {
    let addressFormValidation = true;
    let formFieldError = this.state.formFieldError;
    let username = document.getElementsByName('username')[0].value;
    if (!username) {
      formFieldError['username'] = "User Name Can't be empty";
      addressFormValidation = false;
    }
    let password = document.getElementsByName('password')[0].value;
    if (!password) {
      formFieldError['password'] = "Password Can't be empty";
      addressFormValidation = false;
    }

    if (addressFormValidation) {
      if (username !== this.state.validUserName) {
        formFieldError['username'] = "Invalid User Name";
        this.setState({ formFieldError });
      } else if (password !== this.state.validPassword) {
        formFieldError['password'] = "Invalid Password";
        this.setState({ formFieldError });
      } else {
        localStorage.setItem('username', username);
        window.location.href = process.env.PUBLIC_URL + "/booklists";
      }

    } else {
      this.setState({ formFieldError });
    }
  }

  componentDidMount() {
    if (localStorage.getItem('username')) {
      window.location.href = process.env.PUBLIC_URL + "/booklists";
    }
  }
  
  render() {
    return (
      <div className="container">
        <div className="div-container">
          <div className="card">
            <div className="card-body">
              <form>
                <div className="form-group">
                  <input type="text" name="username" className="form-control" placeholder="UserName..." />
                  <span style={{ color: "red" }}>{this.state.formFieldError["username"]}</span>
                </div>
                <div className="form-group">
                  <input type="password" name="password" className="form-control" placeholder="Password..." />
                  <span style={{ color: "red" }}>{this.state.formFieldError["password"]}</span>
                </div>
                <div className="form-group">
                  <button type="button" className="btn btn-raised  btn-info btn-sm" onClick={() => this.accessLogin()}>Log-In</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    )
  }

}
