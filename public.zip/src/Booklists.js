import React, { Component } from 'react';

export default class Booklists extends Component {
    constructor(props) {
        super(props)
        this.state = {
            bookLists: [],
            bookInformationModal: 'none',
            selectedBookInformation: false
        }
    }

    componentDidMount() {
        if (!localStorage.getItem('username')) {
            window.location.href = process.env.PUBLIC_URL + "/login";
        } else {
            var currentThis = this;
            const API = 'https://www.googleapis.com/books/v1/volumes?filter=free-ebooks&q=a';
            fetch(API).then(res =>
                res.json()).then(data => {
                    console.log(data)
                    currentThis.setState({ bookLists: data.items });
                })
        }

    }

    logOut(){
        localStorage.removeItem('username');
        window.location.href = process.env.PUBLIC_URL + "/login";
    }
    showBookInformation(row) {
        this.setState({
            bookInformationModal: (row) ? 'block' : 'none',
            selectedBookInformation: row
        });
    }
    getBookInformation() {
        const selectedBookInformation = this.state.selectedBookInformation;
        return (
            <div className="modal" tabIndex="-1" role="dialog" style={{ 'display': this.state.bookInformationModal }}>
                {selectedBookInformation ? (
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Book Information</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true" onClick={() => this.showBookInformation(false)} >&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="row">
                                    <div className="col-md-4">
                                        <img src={selectedBookInformation.volumeInfo.imageLinks.thumbnail} alt="book-cover" className="img-thumbnail" />
                                    </div>
                                    <div className="col-md-8">
                                        <h5>{selectedBookInformation.volumeInfo.title}</h5>
                                        <i>{selectedBookInformation.volumeInfo.subtitle}</i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}

            </div>
        )
    }

    loadTable() {
        const bookLists = this.state.bookLists;
        return (
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Image</th>
                        <th scope="col">Title</th>
                    </tr>
                </thead>
                <tbody>
                    {bookLists.length ? (
                        bookLists.map((row, index) => {
                            return (
                                <tr key={index}>
                                    <td>{index + 1}</td>
                                    <td><img onClick={() => this.showBookInformation(row)} src={row.volumeInfo.imageLinks.thumbnail} alt="book-cover" className="img-thumbnail" /></td>
                                    <td className="title">{row.volumeInfo.title}</td>
                                </tr>
                            )
                        })
                    ) : null}
                </tbody>
            </table>
        )
    }
    render() {
        return (
            <div className="container-fluid">
                <div className="col-md-12">
                    <button className="btn btn-sm btn-danger pull-right" onClick={()=>this.logOut()}>Logout</button>
                </div>
                {this.loadTable()}
                <div>
                    {this.getBookInformation()}
                </div>
            </div>
        )
    }
}
