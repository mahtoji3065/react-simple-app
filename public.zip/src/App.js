import React, { Component } from 'react';
import './App.css';
import Login from './Login';
import Booklists from './Booklists';

import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom';


class App extends Component {
  render() {
    return (
      <Router basename={process.env.PUBLIC_URL}>
        <div className="App">
          <Switch>
            <Route exact path="/" render={() => (
              <Redirect to="/login" />
            )} />
            <Route exact path='/login' component={Login} />
            <Route exact path='/booklists' component={Booklists} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
